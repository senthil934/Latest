package com.designpattern.abstractfactory;

//Factory of factories
public interface ComputerAbstractFactory {

	public Computer createComputer();

}