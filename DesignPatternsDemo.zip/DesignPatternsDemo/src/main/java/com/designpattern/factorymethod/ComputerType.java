package com.designpattern.factorymethod;

public enum ComputerType {
PC,
SERVER,
LAPTOP
}
