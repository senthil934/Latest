package com.designpattern.factorymethod;

public class ComputerFactory {

	public static Computer getComputer(ComputerType computerType) {
		if (computerType == null) {
			return null;
		}
		if (computerType == ComputerType.PC) {
			return new PC("2 GB", "500 GB", "2.4 GHz");

		} else if (computerType == ComputerType.LAPTOP) {
			return new Laptop("8 GB", "1 TB", "2.9 GHz");

		} else if (computerType == ComputerType.SERVER) {
			return new Server("16 GB", "1 TB", "2.9 GHz");
		}

		return null;
	}
}