package com.designpattern.factorymethod;

//This type of design pattern comes under creational pattern
public class TestFMDP {

	public static void main(String[] args) {
		//ComputerFactory ComputerFactory = new ComputerFactory();

	      //get an object of Circle and call its displayConfig method.
	      Computer pc = ComputerFactory.getComputer(ComputerType.PC);

	      //call displayConfig method of pc
	      System.out.println("PC Config:"+pc.toString());

	      //get an object of laptop and call its displayConfig method.
	      Computer laptop = ComputerFactory.getComputer(ComputerType.LAPTOP);

	      //call displayConfig method of Rectangle
	      System.out.println("Laptop Config:"+laptop.toString());

	      //get an object of server and call its displayConfig method.
	      Computer server = ComputerFactory.getComputer(ComputerType.SERVER);

	      //call displayConfig method of square
	      System.out.println("Server Config:"+server.toString());

	}

}
