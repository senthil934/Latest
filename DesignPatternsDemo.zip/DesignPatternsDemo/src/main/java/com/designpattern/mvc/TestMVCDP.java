package com.designpattern.mvc;

public class TestMVCDP {

	public static void main(String[] args) {
		// fetch student record based on his roll no from the database
		Student model = retriveStudentFromDatabase();

		// Create a view : to write student details on console
		StudentView view = new StudentView();

		StudentController controller = new StudentController(model, view);
		System.out.println("Initial details of student:");
		controller.updateView();

		System.out.println("Updated details of student:");
		// update model data
		controller.setStudentName("John");

		controller.updateView();
	}

	private static Student retriveStudentFromDatabase() {
		Student student = new Student();
		student.setName("Robert");
		student.setRollNo("10");
		return student;
	}

}
