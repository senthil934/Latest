package com.designpattern.template;

/**
 * In this example, the TransactionTemplate abstract class defines the template
 * method, which is a method that defines the skeleton of an algorithm for
 * making a transaction.
 * 
 * The TransactionTemplate class also defines three abstract methods, which must
 * be implemented by concrete subclasses. The Deposit and Withdrawal classes
 * implement the TransactionTemplate abstract class and provide the specific
 * implementation for the three abstract methods.
 * 
 * The Client class creates the Deposit and Withdrawal objects and then calls
 * the execute() method on each object.
 * 
 * This will cause the template method to be executed, which will in turn cause
 * the three abstract methods to be executed in the order that they are defined.
 * 
 * This code will compile and run and produce the following output:
 * 
 * Verifying customer identity
 * 
 * Checking customer balance
 * 
 * Processing deposit transaction
 * 
 * Verifying customer identity
 * 
 * Checking customer balance
 * 
 * Processing withdrawal transaction
 * 
 * @author anbarasuv
 *
 */

//Abstract Template class
abstract class TransactionTemplate {
	final void execute() {
		verifyCustomerIdentity();
		checkCustomerBalance();
		processTransaction();
	}

	protected abstract void verifyCustomerIdentity();

	protected abstract void checkCustomerBalance();

	protected abstract void processTransaction();
}

//Concrete Template class
class Deposit extends TransactionTemplate {
	@Override
	protected void verifyCustomerIdentity() {
		System.out.println("Verify the customer's identity");
	}

	@Override
	protected void checkCustomerBalance() {
		System.out.println("Check the customer's balance");
	}

	@Override
	protected void processTransaction() {
		System.out.println("Process the deposit transaction");
	}
}

class Withdrawal extends TransactionTemplate {
	@Override
	protected void verifyCustomerIdentity() {
		System.out.println("Verify the customer's identity");
	}

	@Override
	protected void checkCustomerBalance() {
		System.out.println("Check the customer's balance");
	}

	@Override
	protected void processTransaction() {
		System.out.println("Process the withdrawal transaction");
	}
}

//Client code
public class TemplateDemo {
	public static void main(String[] args) {
		TransactionTemplate depositTransaction = new Deposit();
		depositTransaction.execute();

		TransactionTemplate withdrawalTransaction = new Withdrawal();
		withdrawalTransaction.execute();
	}
}