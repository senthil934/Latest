package com.designpattern.adapter;

/**
 * In this example, the OldInsuranceAdapter acts as an adapter that allows the
 * OldInsurance class to be used as an Insurance by implementing the required
 * interface. This adapter pattern facilitates the integration of legacy
 * insurance classes into a system that expects a different interface for
 * insurance calculations.
 * 
 * Let's consider a scenario where there are two existing insurance-related
 * classes: OldInsurance and NewInsurance. The goal is to adapt the OldInsurance
 * class to the interface expected by the system, which is represented by the
 * Insurance interface.
 */
// Existing class with incompatible interface
class OldInsurance {
	public double calculatePremium() {
		// Some legacy logic
		return 500.0;
	}
}

// New interface expected by the system
interface Insurance {
	double calculateInsuranceCost();
}

//Now, let's create an adapter class OldInsuranceAdapter to make the OldInsurance class compatible with the Insurance interface:
// Adapter class
class OldInsuranceAdapter implements Insurance {
	private OldInsurance oldInsurance;

	public OldInsuranceAdapter(OldInsurance oldInsurance) {
		this.oldInsurance = oldInsurance;
	}

	@Override
	public double calculateInsuranceCost() {
		// Adapter converts the method call
		return oldInsurance.calculatePremium();
	}
}
//Now, we can use the OldInsuranceAdapter to adapt the legacy insurance class:

public class InsuranceAdapterExample {
	public static void main(String[] args) {
		// Using the old insurance class through the adapter
		OldInsurance oldInsurance = new OldInsurance();
		Insurance adaptedInsurance = new OldInsuranceAdapter(oldInsurance);

		// Now, we can use the adapted interface
		System.out.println("Insurance Cost: $" + adaptedInsurance.calculateInsuranceCost());
	}
}
