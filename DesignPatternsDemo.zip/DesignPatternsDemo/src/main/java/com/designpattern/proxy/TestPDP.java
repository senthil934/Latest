package com.designpattern.proxy;

//This type of design pattern comes under structural pattern 
public class TestPDP {

	public static void main(String[] args) {
		ProxyInternetAccess proxy = new ProxyInternetAccess("Anbu");
		proxy.accessInternet();
	}

}
