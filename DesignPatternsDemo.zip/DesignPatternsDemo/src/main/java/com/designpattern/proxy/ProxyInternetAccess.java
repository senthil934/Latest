package com.designpattern.proxy;

public class ProxyInternetAccess implements OfficeInternetAccess {

	private String empName;

	private RealInternetAccess realAccess;

	public ProxyInternetAccess(String empname) {
		this.empName = empname;
	}

	public void accessInternet() {
		if (getRole(empName) > 0.3 && getRole(empName) < 0.7) {
			realAccess = new RealInternetAccess(empName);
			realAccess.accessInternet();
		} else {
			System.out.println(empName + "!!! You do not have access to Internet");
		}

	}

	private double getRole(String empName2) {
		// TODO Auto-generated method stub
		return Math.random();
	}

}
