package com.designpattern.proxy;

public interface OfficeInternetAccess {
	public void accessInternet();
}
