package com.designpattern.proxy;

public class RealInternetAccess implements OfficeInternetAccess {
	private String empName;
	public RealInternetAccess(String empname)
	{
		this.empName = empname;
	}
	public void accessInternet() {
		System.out.println("Internet Access is granted for employee " + empName);
		
	}
	
}
