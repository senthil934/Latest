package com.designpattern.decorator;

/**
 * 
 * Consider a banking domain example using the decorator pattern. We'll focus on
 * a scenario where you have a BankAccount class, and you want to add
 * functionalities like overdraft protection and transaction fees dynamically
 * 
 * In this example,
 * 
 * SimpleBankAccount is a basic bank account.
 * 
 * The OverdraftProtectionDecorator adds overdraft protection, allowing
 * withdrawals beyond the account balance up to a limit. The
 * TransactionFeeDecorator adds a transaction fee to each withdrawal. These
 * decorators can be combined to create various bank account configurations
 * based on specific requirements.
 * 
 * @author anbarasuv
 *
 */
public class AccountDecoratorDemo {
	public static void main(String[] args) {
		BankAccount basicAccount = new SimpleBankAccount(1000);
		basicAccount.deposit(500);
		basicAccount.withdraw(200);

		System.out.println("\nDecorated accounts:");

		BankAccount overdraftAccount = new OverdraftProtectionDecorator(new SimpleBankAccount(1000), 500);
		overdraftAccount.withdraw(1500); // Should work due to overdraft protection

		BankAccount feeAccount = new TransactionFeeDecorator(new SimpleBankAccount(1000), 10);
		feeAccount.withdraw(100); // Should apply transaction fee
	}
}

//Component interface
interface BankAccount {
	void deposit(double amount);

	void withdraw(double amount);

	double getBalance();
}

//Concrete component
class SimpleBankAccount implements BankAccount {
	private double balance;

	public SimpleBankAccount(double initialBalance) {
		this.balance = initialBalance;
	}

	@Override
	public void deposit(double amount) {
		balance += amount;
		System.out.println("Deposited $" + amount + ". New balance: $" + balance);
	}

	@Override
	public void withdraw(double amount) {
		if (balance >= amount) {
			balance -= amount;
			System.out.println("Withdrawn $" + amount + ". New balance: $" + balance);
		} else {
			System.out.println("Insufficient funds for withdrawal.");
		}
	}

	@Override
	public double getBalance() {
		return balance;
	}
}

//Decorator
abstract class BankAccountDecorator implements BankAccount {
	protected BankAccount decoratedAccount;

	public BankAccountDecorator(BankAccount account) {
		this.decoratedAccount = account;
	}

	@Override
	public void deposit(double amount) {
		decoratedAccount.deposit(amount);
	}

	@Override
	public void withdraw(double amount) {
		decoratedAccount.withdraw(amount);
	}

	@Override
	public double getBalance() {
		return decoratedAccount.getBalance();
	}
}

//Concrete decorators
class OverdraftProtectionDecorator extends BankAccountDecorator {
	private double overdraftLimit;

	public OverdraftProtectionDecorator(BankAccount account, double overdraftLimit) {
		super(account);
		this.overdraftLimit = overdraftLimit;
	}

	@Override
	public void withdraw(double amount) {
		double availableBalance = getBalance() + overdraftLimit;

		if (availableBalance >= amount) {
			decoratedAccount.withdraw(amount);
		} else {
			System.out.println("Overdraft limit reached. Cannot withdraw $" + amount);
		}
	}
}

class TransactionFeeDecorator extends BankAccountDecorator {
	private double transactionFee;

	public TransactionFeeDecorator(BankAccount account, double transactionFee) {
		super(account);
		this.transactionFee = transactionFee;
	}

	@Override
	public void withdraw(double amount) {
		decoratedAccount.withdraw(amount);
		applyTransactionFee();
	}

	private void applyTransactionFee() {
		double currentBalance = getBalance();
		double newBalance = currentBalance - transactionFee;
		System.out.println("Applied transaction fee of $" + transactionFee + ". New balance: $" + newBalance);
	}
}