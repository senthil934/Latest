package com.designpattern.composite;

import java.util.ArrayList;
import java.util.List;

/**
 * Imagine a file system where a file can be a directory or a regular file. A
 * directory can contain multiple files and subdirectories. To implement this
 * system using the Composite design pattern, we can create a File interface
 * that represents both files and directories. We can then create concrete
 * classes for File and Directory that implement the File interface. The File
 * class would have methods for getting the file name, size, and contents. The
 * Directory class would have methods for getting the directory name, size, and
 * contents, as well as methods for adding and removing files and subdirectories
 * from the directory. We can then create a Composite class that implements the
 * File interface and provides the functionality for adding and removing files
 * and subdirectories from the composite.
 * 
 * @author anbarasuv
 *
 */
//File interface
interface File {
	String getName();

	long getSize();

	String getContents();
}

//Concrete File class
class ConcreteFile implements File {
	private String name;
	private long size;
	private String contents;

	ConcreteFile(String name, long size, String contents) {
		this.name = name;
		this.size = size;
		this.contents = contents;
	}

	public String getName() {
		return name;
	}

	public long getSize() {
		return size;
	}

	public String getContents() {
		return contents;
	}
}

//Concrete Directory class
class ConcreteDirectory implements File {
	private String name;
	private List<File> files;

	ConcreteDirectory(String name) {
		this.name = name;
		this.files = new ArrayList<>();
	}

	public String getName() {
		return name;
	}

	public long getSize() {
		long size = 0;
		for (File file : files) {
			size += file.getSize();
		}
		return size;
	}

	public String getContents() {
		StringBuilder contents = new StringBuilder();
		for (File file : files) {
			contents.append(file.getContents());
		}
		return contents.toString();
	}

	void addFile(File file) {
		files.add(file);
	}

	void removeFile(File file) {
		files.remove(file);
	}
}

//Composite class
class Composite implements File {
	private String name;
	private List<File> files;

	Composite(String name) {
		this.name = name;
		this.files = new ArrayList<>();
	}

	public String getName() {
		return name;
	}

	public long getSize() {
		long size = 0;
		for (File file : files) {
			size += file.getSize();
		}
		return size;
	}

	public String getContents() {
		StringBuilder contents = new StringBuilder();
		for (File file : files) {
			contents.append(file.getContents());
		}
		return contents.toString();
	}

	void addFile(File file) {
		files.add(file);
	}

	void removeFile(File file) {
		files.remove(file);
	}
}

//Client code
public class CompositeDemo {
	public static void main(String[] args) {
		File file1 = new ConcreteFile("file1.txt", 100, "This is the content of file1.txt");
		File file2 = new ConcreteFile("file2.txt", 200, "This is the content of file2.txt");

		ConcreteDirectory directory1 = new ConcreteDirectory("directory1");
		directory1.addFile(file1);
		directory1.addFile(file2);

		File file3 = new ConcreteFile("file3.txt", 300, "This is the content of file3.txt");

		ConcreteDirectory directory2 = new ConcreteDirectory("directory2");
		directory2.addFile(file3);

		ConcreteDirectory directory3 = new ConcreteDirectory("directory3");
		directory3.addFile(directory1);
		directory3.addFile(directory2);

		System.out.println("The size of directory3 is: " + directory3.getSize());
	}
}