package com.designpattern.state;

/**
 * In this example, the State interface defines the methods that can be called
 * on a state.
 * 
 * The RedState, GreenState, and YellowState classes implement the State
 * interface and provide the specific behavior for each state.
 * 
 * RedState -> after the action move to next state "Yellow"
 * 
 * YellowState -> after the action move to next state "Green" / "Red"
 * 
 * GreenState -> after the action move to next state "Yellow"
 * 
 * The TrafficLight class represents the traffic light and has a State property
 * that represents the current state of the traffic light.
 * 
 * The doAction() method calls the doAction() method on the current state.
 * 
 * The Client class creates the TrafficLight object and then calls the
 * doAction() method three times. This will cause the traffic light to change
 * from red to green to yellow to red.
 * 
 * @author anbarasuv
 *
 */
//State interface
interface State {
	void doAction(TrafficLight trafficLight);
}

//Concrete State classes
class RedState implements State {
	@Override
	public void doAction(TrafficLight trafficLight) {
		System.out.println("Red light");
		trafficLight.setState(new YellowState());
	}
}

class GreenState implements State {
	@Override
	public void doAction(TrafficLight trafficLight) {
		System.out.println("Green light");
		trafficLight.setState(new YellowState());
	}
}

class YellowState implements State {
	@Override
	public void doAction(TrafficLight trafficLight) {
		System.out.println("Yellow light");
		trafficLight.setState(new GreenState());
	}
}

//Context class
class TrafficLight {
	private State state;

	public TrafficLight() {
		this.state = new RedState();
	}

	public void setState(State state) {
		this.state = state;
	}

	public void doAction() {
		state.doAction(this);
	}
}

//Client code
public class StateDemo {
	public static void main(String[] args) {
		TrafficLight trafficLight = new TrafficLight();

		for (int i = 0; i < 3; i++) {
			trafficLight.doAction();
		}
	}
}
