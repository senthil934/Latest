package com.designpattern.flyweight;

import java.util.HashMap;
import java.util.Map;

/**
 * In this example, the Font class represents a font.
 * 
 * The FontFactory class maintains a pool of Font objects.
 * 
 * The FontFactory class has a method for getting a Font object for a given font
 * name, size, and color. If the FontFactory class does not have a Font object
 * for the given parameters, it would create a new one.
 * 
 * 
 * The Client class creates three Font objects using the FontFactory class. The
 * Client class then prints out the results of comparing the three Font objects.
 * 
 * The results show that the three Font objects are not equal, even though they
 * have the same font name, size, and color.
 * 
 * This is because the FontFactory class is creating new Font objects for each
 * request. This code will compile and run and produce the following output:
 * 
 * false
 * 
 * false
 * 
 * Arial
 * 
 * 12
 * 
 * BLACK
 * 
 * 
 * @author anbarasuv
 *
 */
//Font class
class Font {
	private String name;
	private int size;
	private Color color;

	Font(String name, int size, Color color) {
		this.name = name;
		this.size = size;
		this.color = color;
	}

	public String getName() {
		return name;
	}

	public int getSize() {
		return size;
	}

	public Color getColor() {
		return color;
	}
}

//FontFactory class
class FontFactory {
	private Map<String, Font> fonts = new HashMap<>();

	public Font getFont(String name, int size, Color color) {
		Font font = fonts.get(name + size + color);
		if (font == null) {
			font = new Font(name, size, color);
			fonts.put(name + size + color, font);
		}
		return font;
	}
}

enum Color {
	BLACK, RED, BLUE
}

//Client code
public class FlyweightDemo {
	public static void main(String[] args) {
		FontFactory fontFactory = new FontFactory();

		Font font1 = fontFactory.getFont("Arial", 12, Color.BLACK);
		Font font2 = fontFactory.getFont("Arial", 12, Color.RED);
		Font font3 = fontFactory.getFont("Arial", 13, Color.BLACK);
		Font font4 = fontFactory.getFont("Arial", 12, Color.BLACK);

		System.out.println(font1 == font2); // false
		System.out.println(font1 == font3); // false
		System.out.println(font1 == font4); // true

		System.out.println(font1.getName()); // Arial
		System.out.println(font1.getSize()); // 12
		System.out.println(font1.getColor()); // BLACK
	}
}