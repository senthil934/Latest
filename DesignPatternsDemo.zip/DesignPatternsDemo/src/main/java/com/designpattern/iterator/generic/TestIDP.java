package com.designpattern.iterator.generic;

import java.util.ArrayList;
import java.util.List;

//this pattern falls under behavioral pattern category.
public class TestIDP {

	public static void main(String[] args) {
		List<String> ar = new ArrayList<String>();
		ar.add("a");
		ar.add("c");
		ar.add("e");
		ar.add("t");
		NameRepository<String> namesRepository = new NameRepository<String>(ar);

		for (Iterator<String> iter = namesRepository.getIterator(); iter.hasNext();) {
			String name = iter.next();
			String previousname =  iter.previous();
			if (previousname != null)
				System.out.println("Current Name : " + name + " : Previous Name : " + previousname);
			else
				System.out.println("Current Name : " + name);
		}
		
		//Class Object
		
		List<Student> ar2 = new ArrayList<Student>();
		ar2.add(new Student(1,"A"));
		ar2.add(new Student(2,"A3"));
		ar2.add(new Student(3,"A2"));
		ar2.add(new Student(4,"A1"));
		NameRepository<Student> stuRepository2 = new NameRepository<Student>(ar2);

		for (Iterator<Student> iter = stuRepository2.getIterator(); iter.hasNext();) {
			Student name = iter.next();
			Student previousname =  iter.previous();
			if (previousname != null)
				System.out.println("Current Student : " + name + " : Previous Student : " + previousname);
			else
				System.out.println("Current Student : " + name);
		}

	}

}
