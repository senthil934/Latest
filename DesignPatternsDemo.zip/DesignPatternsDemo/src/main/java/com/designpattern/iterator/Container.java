package com.designpattern.iterator;

public interface Container {
	public Iterator getIterator();
}
