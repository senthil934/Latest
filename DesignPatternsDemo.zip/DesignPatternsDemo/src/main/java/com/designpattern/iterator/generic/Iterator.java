package com.designpattern.iterator.generic;

public interface Iterator<T> {
	public boolean hasNext();
	public T next();
	public boolean hasPrevious();
	public T previous();
}
