package com.designpattern.iterator.generic;

public interface Container {
	public Iterator<?> getIterator();
}
