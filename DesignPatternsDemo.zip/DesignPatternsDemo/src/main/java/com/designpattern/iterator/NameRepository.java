package com.designpattern.iterator;

public class NameRepository implements Container {
	String names[] = { "A", "B", "C", "D" };

	public Iterator getIterator() {
		// TODO Auto-generated method stub
		return new NameIterator();
	}

	private class NameIterator implements Iterator {

		int index;

		public boolean hasNext() {

			if (index < names.length) {
				return true;
			}
			return false;
		}

		public Object next() {

			if (this.hasNext()) {
				return names[index++];
			}
			return null;
		}

		public boolean hasPrevious() {
			if ((index - 1) > 0 && index <= names.length) {
				return true;
			}
			return false;
		}

		public Object previous() {
			if (this.hasPrevious()) {
				return names[index - 2];
			}
			return null;
		}
	}
}
