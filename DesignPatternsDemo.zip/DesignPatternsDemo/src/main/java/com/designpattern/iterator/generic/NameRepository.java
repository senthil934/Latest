package com.designpattern.iterator.generic;

import java.util.List;

public class NameRepository<T> implements Container {
	List<T> inputList;
	public NameRepository(List<T> t) {
		inputList = t;
	}

	public Iterator<T> getIterator() {
		// TODO Auto-generated method stub
		return new NameIterator<>();
	}

	private class NameIterator<T> implements Iterator<T> {

		int index;

		public boolean hasNext() {

			if (index < inputList.size()) {
				return true;
			}
			return false;
		}

		public T next() {

			if (this.hasNext()) {
				return (T) inputList.get(index++);
			}
			return null;
		}

		public boolean hasPrevious() {
			if ((index - 1) > 0 && index <= inputList.size()) {
				return true;
			}
			return false;
		}

		public T previous() {
			if (this.hasPrevious()) {
				return (T) inputList.get(index - 2);
			}
			return null;
		}
	}
}
