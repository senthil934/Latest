package com.designpattern.iterator;


// this pattern falls under behavioral pattern category.
public class TestIDP {

	public static void main(String[] args) {
		NameRepository namesRepository = new NameRepository();

		for (Iterator iter = namesRepository.getIterator(); iter.hasNext();) {
			String name = (String) iter.next();
			String previousname = (String) iter.previous();
			if (previousname != null)
				System.out.println("Current Name : " + name + " : Previous Name : " + previousname);
			else
				System.out.println("Current Name : " + name);
		}

	}

}
