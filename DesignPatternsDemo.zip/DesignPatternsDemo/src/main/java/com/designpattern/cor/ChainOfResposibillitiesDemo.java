package com.designpattern.cor;

/**
 * In this example, the Handler abstract class defines the methods that can be
 * called on a handler.
 * 
 * The DepositHandler, WithdrawalHandler, and TransferHandler classes implement
 * the Handler interface and provide the specific behavior for each type of
 * transaction.
 * 
 * The Client class creates the handlers and then calls the handleRequest()
 * method on the first handler in the chain.
 * 
 * The handleRequest() method checks the type of the transaction and then calls
 * the appropriate method on the next handler in the chain, if there is one.
 * 
 * This code will compile and run and produce the following output:
 * 
 * Processing deposit transaction
 * 
 * Processing withdrawal transaction
 * 
 * Processing transfer transaction
 * 
 * @author anbarasuv
 *
 */
//Abstract Handler class
abstract class Handler {
	protected Handler nextHandler;

	void setNextHandler(Handler nextHandler) {
		this.nextHandler = nextHandler;
	}

	abstract void handleRequest(Transaction transaction);
}

//Concrete Handler classes
class DepositHandler extends Handler {
	@Override
	void handleRequest(Transaction transaction) {
		if (transaction.getType() == TransactionType.DEPOSIT) {
			// Process the deposit transaction
			System.out.println("Processing Deposit Transaction");
		} else {
			this.nextHandler.handleRequest(transaction);
		}
	}
}

class WithdrawalHandler extends Handler {
	@Override
	void handleRequest(Transaction transaction) {
		if (transaction.getType() == TransactionType.WITHDRAWAL) {
			// Process the withdrawal transaction
			System.out.println("Processing Withdrawal Transaction");
		} else {
			this.nextHandler.handleRequest(transaction);
		}
	}
}

class TransferHandler extends Handler {
	@Override
	void handleRequest(Transaction transaction) {
		if (transaction.getType() == TransactionType.TRANSFER) {
			// Process the transfer transaction
			System.out.println("Processing Transfer Transaction");
		} else {
			this.nextHandler.handleRequest(transaction);
		}
	}
}

//Transaction class
class Transaction {
	private TransactionType type;
	private double amount;

	Transaction(TransactionType type, double amount) {
		this.type = type;
		this.amount = amount;
	}

	TransactionType getType() {
		return type;
	}

	double getAmount() {
		return amount;
	}
}

//Transaction Type enum
enum TransactionType {
	DEPOSIT, WITHDRAWAL, TRANSFER
}

//Client class
public class ChainOfResposibillitiesDemo {
	public static void main(String[] args) {
		Handler depositHandler = new DepositHandler();
		Handler withdrawalHandler = new WithdrawalHandler();
		Handler transferHandler = new TransferHandler();

		depositHandler.setNextHandler(withdrawalHandler);
		withdrawalHandler.setNextHandler(transferHandler);

		Transaction depositTransaction = new Transaction(TransactionType.DEPOSIT, 1000.00);
		depositHandler.handleRequest(depositTransaction);

		Transaction withdrawalTransaction = new Transaction(TransactionType.WITHDRAWAL, 500.00);
		withdrawalHandler.handleRequest(withdrawalTransaction);

		Transaction transferTransaction = new Transaction(TransactionType.TRANSFER, 250.00);
		transferHandler.handleRequest(transferTransaction);
	}
}
