package com.designpattern.facade;

import com.designpattern.factorymethod.PC;
import com.designpattern.factorymethod.Server;

public class ComputerMaker {
	private Laptop laptop;
	private PC pc;
	private Server server;

	public ComputerMaker() {
		this.laptop = new Laptop("8 GB", "1 TB", "2.9 GHz");
		this.server =new Server("16 GB", "1 TB", "2.9 GHz");
		this.pc = new PC("2 GB", "500 GB", "2.4 GHz");
				
	}
	
	public void getPCConfig()
	{
		System.out.println(this.pc.toString());
	}
	
	public void getServerConfig()
	{
		System.out.println(this.server.toString());
	}
	
	public void getLaptopConfig()
	{
		System.out.println(this.laptop.toString());
	}

}
