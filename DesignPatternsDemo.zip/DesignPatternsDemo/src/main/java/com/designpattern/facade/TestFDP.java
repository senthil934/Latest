package com.designpattern.facade;

//This type of design pattern comes under structural pattern 
public class TestFDP {

	public static void main(String[] args) {
		ComputerMaker computerMaker = new ComputerMaker();

		computerMaker.getPCConfig();
		computerMaker.getServerConfig();
		computerMaker.getLaptopConfig();
	}
}